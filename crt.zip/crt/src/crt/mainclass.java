package crt;

public class mainclass {
	public static void main(String args[])
	{
		acessmodifers a1=new acessmodifers();
		a1.display();
		Another a=new Another();
		a.display();
		
		
	}

}
