package crt;
import java.util.Scanner;
public class Sample2 {
public static void main(String []args){
	Scanner sc=new Scanner(System.in);
	for(int i=1;i<=4;i++) {
		int a=sc.nextInt();
		int sum=a-(50*i);
		System.out.println(sum);
	}
}

}
