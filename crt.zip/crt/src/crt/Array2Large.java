package crt;
import java.util.Arrays;
public class Array2Large {
	public static void main(String args[]) {
        int[] numbers = {10, 36, 25,28, 19};
        Arrays.sort(numbers);

        int largest = numbers[numbers.length - 1];
        int secondLargest = -1;

        for (int i = numbers.length - 2; i >= 0; i--) {
            if (numbers[i] < largest) {
                secondLargest = numbers[i];
                break;
            }
        }

        if (secondLargest != -1) {
            System.out.println("Second largest unique number is: " + secondLargest);
        } else {
            System.out.println("No second largest unique number found.");
        }
    }


	}


