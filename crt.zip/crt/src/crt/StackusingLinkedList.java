package crt;

import java.util.LinkedList;

public class StackusingLinkedList {
private static final String Syso = null;

public static void main(String[]args) {
	LinkedList<Integer>Stack=new LinkedList<>();
	Stack.push(10);
	Stack.push(20);
	Stack.push(30);
	System.out.println("Stack: "+Stack);
	System.out.println("popped: "+Stack.pop());
	System.out.println("top: "+Stack.pop());
	System.out.println("Stack after pop: "+Stack);
	
}
}
