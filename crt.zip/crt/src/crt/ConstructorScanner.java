package crt;

import java.util.Scanner;

class Person {
	String name;
	int age;
	public Person(String name,int age) {
		this.name=name;
		this.age=age;
	}
	public void Display()
	{
		System.out.println("Name:"+name);
		System.out.println("Age:"+age);
	}
}
public class ConstructorScanner{
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
        System.out.println("enter the name: ");
        String name=sc.nextLine();
        System.out.println("enter age: ");
        int age=sc.nextInt();
        Person person=new Person(name,age);
        person.Display();
		
	}
	
}
//constructor using scanner 