package crt;
import java.util.Arrays;
public class ReverseArray {
public static void main(String args[]) {
	int a[]= {12,23,34,45,56};
	int copy[]=Arrays.copyOf(a, a.length);
	for(int i=0;i<copy.length/2;i++) {
		int temp=copy[i];
		copy[i]=copy[copy.length-1-i];
		copy[copy.length-1-i]=temp;
		
	}
	System.out.println("Original Array: "+ Arrays.toString(a));
	System.out.println("Reverse array:"+ Arrays.toString(copy));
}
}
