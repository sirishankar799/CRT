package crt;
import java.util.Scanner;
public class StringLen {
public static void main(String args[]) {
	
}
}
