package crt;
import java.util.Arrays;
public class ArrayBinarySearch {
	public static void main(String args[]){
	int arr[]= {20,70,60,10,30};
	int key=60;
	System.out.println("Sorted array: "+Arrays.toString(arr));
	int index=Arrays.binarySearch(arr, key);
	if(index >= 0) {
		System.out.println(key + "found at index: "+ index);
	}
	else {
		System.out.println(key + "not found in the array.");
	}
	}

}
