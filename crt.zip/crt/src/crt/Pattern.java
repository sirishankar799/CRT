package crt;

public class Pattern {
	    public static void main(String[] args) {
	    	        int rows = 7, cols = 7;

	    	        for (int i = 0; i < rows; i++) {
	    	            for (int j = 0; j < cols; j++) {
	    	               
	    	                if ((i == 0 && j > 0 && j < cols - 1) ||              
	    	                    (i == rows / 2 && j > 0 && j < cols - 1) ||      
	    	                    (i == rows - 1 && j > 0 && j < cols - 1) ||         
	    	                    (j == 0 && i > 0 && i < rows / 2) ||                  
	    	                    (j == cols - 1 && i > rows / 2 && i < rows - 1)) {   
	    	                    System.out.print("*");
	    	                } else {
	    	                    System.out.print(" ");
	    	                }
	    	            }
	    	            System.out.println();
	    	        }
	    	    }
	    	}
