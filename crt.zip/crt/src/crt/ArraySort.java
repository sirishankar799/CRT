package crt;
import java.util.Arrays;
class ArraySort {
	public static void main(String args[]) {
		int marks[]= {98,43,21,46,71,82,26,74};
		System.out.println("Array1: "+Arrays.toString(marks));
		Arrays.sort(marks);
		System.out.println("ascending order: "+Arrays.toString(marks));
	}

}
