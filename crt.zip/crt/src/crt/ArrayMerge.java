package crt;
import java.util.Arrays;
import java.util.Scanner;
public class ArrayMerge {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter size of 1st array: ");
	int n1=sc.nextInt();
	int arr1[]=new int[n1];
	System.out.println("enter"+ n1 + "elements for 1st array: ");
	for(int i=0;i<n1;i++) {
		arr1[i]=sc.nextInt();
		}
	System.out.println("enter size of 2nd array: ");
	int n2=sc.nextInt();
	int arr2[]=new int[n2];
	System.out.println("enter"+ n2 + "elements for 2nd array: ");
	for(int i=0;i<n2;i++) {
		arr2[i]=sc.nextInt();
		}
int[]merged=Arrays.copyOf(arr1, n1+n2);
for(int i=0;i<n2;i++) {
	merged[n1+i]=arr2[i];
}
System.out.println("Merged Array:"+ Arrays.toString(merged));	
}
}
