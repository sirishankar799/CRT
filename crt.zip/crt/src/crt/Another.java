package crt;

public class Another {
	public int  a=15;
	private int b=9;
	protected int c=78;
	int d=56;
	void display()
	{
		System.out.println("a"+a);
		System.out.println("b"+b);
		System.out.println("c"+c);
		System.out.println("d"+d);
		
	}

}
