package crt;
import java.util.Scanner;
public class Reverse {
public static void main(String[]args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter a number: ");
	int num=sc.nextInt();
	int n=num;
	int reverse=0;
	while(num!=0)
	{
		int i=num%10;
	    reverse=reverse*10+i;
	    num/=10;
	}
	System.out.println("reversenumber"+n+"is"+reverse);
	sc.close();
}
}
