package crt;
import java.util.HashMap;
	import java.util.Scanner;

	public class HashMapExample {  
	    public static void main(String[] args) {
	        HashMap<String, Integer> students = new HashMap<>();
	        students.put("abc", 123);
	        students.put("xyz", 567);
	        students.put("pqr", 678);

	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter name: ");
	        String name = sc.nextLine();

	        if (students.containsKey(name)) {
	            System.out.println("Number: " + students.get(name));
	        } else {
	            System.out.println("Student not found");
	        }

	        sc.close();
	    }
	}

