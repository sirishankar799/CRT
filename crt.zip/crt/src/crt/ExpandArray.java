package crt;
import java.util.Arrays;
public class ExpandArray {

	    public static void main(String[] args) {
	     
	        int[] original = {1, 2, 3, 4, 5};

	
	        int[] larger = Arrays.copyOf(original, 10);
              
	       
	        System.out.println("Original array: " + Arrays.toString(original));
	        System.out.println("Expanded array (size 10): " + Arrays.toString(larger));
	    
	}
}


