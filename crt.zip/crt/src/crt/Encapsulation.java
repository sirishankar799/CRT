package crt;
import java.util.*;
public class Encapsulation {
private int bal=10;
public int ac_no=1929384756;
public void setbal(int ba) {
	
}
}
