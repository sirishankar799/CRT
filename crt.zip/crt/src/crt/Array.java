package crt;
import java.util.Arrays;
public class Array {
public static void main(String args[]) {
	int a[]= {20,3,42,2,3};
	int marks[]= {44,35,66,77,48,49};
	for(int i=0;i<a.length-4;i++)
	{
		System.out.println("Array1: "+Arrays.toString(marks));
		System.out.println("Array2: "+Arrays.toString(a));
		Arrays.sort(a);
		Arrays.sort(marks);
		System.out.println("Sorted Array 1: " + Arrays.toString(a));
        System.out.println("Sorted Array 2: " + Arrays.toString(marks));

        int largest = a[0];

        for (int num : a) {
            if (num > largest) {
                largest = num;
            }
        }

        for (int num : marks) {
        	if (num > largest) {
        		largest = num;
        	}
        }
        System.out.println("Largest element from both arrays is: " + largest);

	}
}
}
