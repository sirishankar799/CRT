package crt;
import java.util.Arrays;
public class FillArray {
	public static void main(String args[]) {
		int size=7;
		int array[]=new int[size];
		Arrays.fill(array,-1);
		System.out.println("Array fikkedwith -1: "+Arrays.toString(array));
		
	}

}
