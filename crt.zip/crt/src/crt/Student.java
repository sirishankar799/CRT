package crt;
class Stu {
	
		String name;
		int age;
		public Stu(String name,int age) {
			this.name=name;
			this.age=age;
	}
		public void Display()
		{
			System.out.println("Name: "+name);
			System.out.println("Age: "+age);
		}
}
		public class Student{
			
		public static void main(String[]args)
		{
		   Stu student1=new Stu("dolly",20);
			student1.Display();
		}
 }
//constructor