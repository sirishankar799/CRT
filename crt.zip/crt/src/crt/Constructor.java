package crt;

import java.util.Scanner;

class Child {
String name;
int number;
public Child(String ChildName,int ChildNumber)
{
	name=ChildName;
	number=ChildNumber;
}
public void Display() {
	System.out.println("Name: "+name);
	System.out.println("Number:"+number);
}
}
public class Constructor{
	public static void main(String[]args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter Name: ");
		String n1=sc.nextLine();
		System.out.println("enter number: ");
		int num1=sc.nextInt();
		Child child=new Child(n1,num1);
		child.Display();
	}
}


